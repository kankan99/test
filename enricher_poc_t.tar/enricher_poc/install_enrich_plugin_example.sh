cp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar /usr/hdp/3.1.0.0-78/hive/lib/ranger-hive-plugin-impl
cp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar /usr/hdp/3.1.0.0-78/ranger-hive-plugin/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kw1:/usr/hdp/3.1.0.0-78/hive/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kw2:/usr/hdp/3.1.0.0-78/hive/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kwx0:/usr/hdp/3.1.0.0-78/hive/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kwx1:/usr/hdp/3.1.0.0-78/hive/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kw1:/usr/hdp/3.1.0.0-78/ranger-hive-plugin/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kw2:/usr/hdp/3.1.0.0-78/ranger-hive-plugin/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kwx0:/usr/hdp/3.1.0.0-78/ranger-hive-plugin/lib/ranger-hive-plugin-impl
scp /tmp/conditions-enrichers-1.2.1-SNAPSHOT.jar kwx1:/usr/hdp/3.1.0.0-78/ranger-hive-plugin/lib/ranger-hive-plugin-impl


